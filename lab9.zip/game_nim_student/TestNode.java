package game_nim_student;

import java.util.Arrays;
import java.util.List;

public class TestNode {
	public static void main(String[] args) {
		//test with 7 tokens
		Node node7 = new Node();
		Integer[] data = { 7 };
		node7.addAll(Arrays.asList(data));

		MinimaxAlgo algo = new MinimaxAlgo();
		algo.execute(node7);
		
		//test with 8 tokens
		Node node8 = new Node();
		Integer[] data8 = { 8 };
		node8.addAll(Arrays.asList(data));

		MinimaxAlgo algo8 = new MinimaxAlgo();
		algo.execute(node8);
		
		//test with 9 tokens
		Node node9 = new Node();
        Integer[] data9 = { 9 };
        node9.addAll(Arrays.asList(data9));
        testMinimaxAlgo(node9);
	}

	private static void testMinimaxAlgo(Node node9) {
		// TODO Auto-generated method stub
		MinimaxAlgo algo = new MinimaxAlgo();
        String node;
		System.out.println("Testing with tokens: " + node);
        algo.execute(node);
        System.out.println("-------------------------");
	}
}