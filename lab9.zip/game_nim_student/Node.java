package game_nim_student;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Node {
	private List<Integer> data = new ArrayList<Integer>();

	public void add(Integer val) {
		this.data.add(val);
	}

	public void addAll(List<Integer> data) {
		this.data.addAll(data);
	}

	// Get children of the current nodes
	public List<Node> getSuccessors() {
		// Enter your code here
		List<Node> successors = new ArrayList<>();

		for (int i = 0; i < data.size(); i++) {
			for (int j = i + 1; j < data.size(); j++) {
				int diff = Math.abs(data.get(i) - data.get(j));
				if (diff > 0) {
					Node successor = new Node();
					List<Integer> newData = new ArrayList<>(data);
					newData.remove(i);
					newData.remove(j - 1);
					newData.add(diff);
					successor.addAll(newData);
					successors.add(successor);
				}
			}
		}

		return successors;
	}

	// Check whether a node is terminal or not
	public boolean isTerminal() {
		// Enter your code here
		return data.size() == 1;
	}

	public static final Comparator<Integer> DESCOMPARATOR1 = new Comparator<Integer>() {

		@Override
		public int compare(Integer o1, Integer o2) {
			return o2.compareTo(o1);
		}
	};

	public static final Comparator<Integer> DESCOMPARATOR = new Comparator<Integer>() {

		@Override
		public int compare(Integer o1, Integer o2) {
			return o2.compareTo(o1);
		}
	};

	@Override
	public String toString() {
		Collections.sort(this.data, DESCOMPARATOR1);
		return this.data.toString();
	}
	
	 public static void main(String[] args) {
	        // Example usage
	        Node node = new Node();
	        node.addAll(List.of(4, 5, 6));
	        System.out.println("Node: " + node);
	        System.out.println("Is Terminal? " + node.isTerminal());
	        System.out.println("Successors: " + node.getSuccessors());
	    }
}
